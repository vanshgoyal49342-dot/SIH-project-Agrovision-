const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const { makeStore } = require('./lib/jsonStore');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';

// ---------- stores ----------
const usersStore = makeStore('users.json', []);
const centersStore = makeStore('centers.json', []);
const vendorsStore = makeStore('vendors.json', []);
const mspStore = makeStore('msp.json', []);
const slotsStore = makeStore('slots.json', []);
const bookingsStore = makeStore('bookings.json', []);

const TIME_WINDOWS = ['08:00 - 10:00', '10:00 - 12:00', '13:00 - 15:00', '15:00 - 17:00'];
const SLOT_CAPACITY = 8;
const DAYS_AHEAD = 5;

function reseedSlots() {
  const centers = centersStore.read();
  const bookings = bookingsStore.read();
  const slots = [];
  let id = 1;

  for (let d = 0; d < DAYS_AHEAD; d++) {
    const dt = new Date();
    dt.setDate(dt.getDate() + d);
    const dateStr = dt.toISOString().slice(0, 10);

    centers.forEach(c => {
      TIME_WINDOWS.forEach(tw => {
        const bookedCount = bookings.filter(
          b => b.center_code === c.code && b.date === dateStr && b.time === tw && b.status !== 'Cancelled'
        ).length;
        slots.push({
          id: id++,
          center_code: c.code,
          center_name: c.name,
          center_location: c.location,
          date: dateStr,
          time: tw,
          capacity: SLOT_CAPACITY,
          booked: bookedCount
        });
      });
    });
  }
  slotsStore.write(slots);
  return slots;
}

function generateToken(centerCode, dateStr) {
  const bookings = bookingsStore.read();
  const datePart = dateStr.replace(/-/g, '');
  const prefix = `${centerCode}-${datePart}-`;
  const existing = bookings.filter(b => b.token.startsWith(prefix));
  let seq = 1;
  if (existing.length) {
    const nums = existing.map(b => parseInt(b.token.split('-').pop(), 10));
    seq = Math.max(...nums) + 1;
  }
  return prefix + String(seq).padStart(3, '0');
}

// ---------- auth helpers ----------
function publicUser(u) {
  const { passwordHash, ...safe } = u;
  return safe;
}

function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Not authenticated.' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: 'Session expired, please sign in again.' });
  }
}


function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required.' });
  }
  next();
}

/* =========================================================
   AUTH
   ========================================================= */

app.post('/api/auth/register', async (req, res) => {
  const { name, email, password, state, district, phone, pincode, aadhaar, cropType } = req.body || {};

  if (!name || !name.trim()) return res.status(400).json({ field: 'regName', error: 'Full name is required.' });
  if (!email || !email.trim()) return res.status(400).json({ field: 'regEmail', error: 'Email or farmer ID is required.' });
  if (!password || password.length < 6) return res.status(400).json({ field: 'regPassword', error: 'Password must be at least 6 characters.' });
  if (!/^[0-9]{10}$/.test(phone || '')) return res.status(400).json({ field: 'regPhone', error: 'Enter a valid 10-digit contact number.' });
  if (!/^[0-9]{6}$/.test(pincode || '')) return res.status(400).json({ field: 'regPincode', error: 'Enter a valid 6-digit PIN code.' });
  if (!/^[0-9]{12}$/.test(aadhaar || '')) return res.status(400).json({ field: 'regAadhaar', error: 'Enter a valid 12-digit Aadhaar number.' });

  const users = usersStore.read();
  if (users.some(u => u.email.toLowerCase() === email.trim().toLowerCase())) {
    return res.status(409).json({ field: 'regEmail', error: 'An account with this email/farmer ID already exists.' });
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const aadhaarMasked = `XXXX-XXXX-${aadhaar.slice(-4)}`;

  const user = {
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 8),
    name: name.trim(),
    email: email.trim(),
    passwordHash,
    role: 'farmer', 
    state: state || '',
    district: district || '',
    phone,
    pincode,
    aadhaarMasked,
    cropType: cropType || 'Rabi',
    createdAt: new Date().toISOString()
  };

  users.push(user);
  usersStore.write(users);

  const token = jwt.sign({ sub: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
  res.status(201).json({ token, user: publicUser(user) });
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password, role } = req.body || {};

  if (!email || !email.trim()) return res.status(400).json({ field: 'email', error: 'Enter your email or farmer ID to continue.' });
  if (!password) return res.status(400).json({ field: 'password', error: 'Enter your password to continue.' });

  const users = usersStore.read();
  const user = users.find(u => u.email.toLowerCase() === email.trim().toLowerCase());
  if (!user) return res.status(401).json({ error: 'Invalid email/farmer ID or password.' });

  const match = await bcrypt.compare(password, user.passwordHash);
  if (!match) return res.status(401).json({ error: 'Invalid email/farmer ID or password.' });

  if (role && user.role !== role) {
    return res.status(403).json({ error: `This account is registered as "${user.role}", not "${role}".` });
  }

  const token = jwt.sign({ sub: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: publicUser(user) });
});

app.get('/api/auth/me', requireAuth, (req, res) => {
  const users = usersStore.read();
  const user = users.find(u => u.id === req.user.sub);
  if (!user) return res.status(404).json({ error: 'User not found.' });
  res.json({ user: publicUser(user) });
});

/* =========================================================
   REFERENCE DATA
   ========================================================= */

app.get('/api/msp', (req, res) => {
  res.json(mspStore.read());
});

app.get('/api/centers', (req, res) => {
  res.json(centersStore.read());
});

app.get('/api/vendors', (req, res) => {
  const { type, district } = req.query;
  let vendors = vendorsStore.read();
  if (type) vendors = vendors.filter(v => v.type === type);
  if (district) vendors = vendors.filter(v => v.district === district);
  res.json(vendors);
});

/* =========================================================
   SLOTS
   ========================================================= */

app.get('/api/slots', (req, res) => {
  const todayStr = new Date().toISOString().slice(0, 10);
  const slots = slotsStore.read()
    .filter(s => s.date >= todayStr && s.booked < s.capacity)
    .sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
  res.json(slots);
});

/* =========================================================
   BOOKINGS
   ========================================================= */

// Create a booking (requires login)
app.post('/api/bookings', requireAuth, (req, res) => {
  const { slotId, farmer_name, farmer_phone, farmer_village, crop_type, quantity } = req.body || {};

  if (!farmer_name || !farmer_phone || !crop_type || !quantity) {
    return res.status(400).json({ error: 'Name, phone, crop type and quantity are required.' });
  }

  const slots = slotsStore.read();
  const slot = slots.find(s => s.id === slotId);
  if (!slot) return res.status(404).json({ error: 'Slot not found.' });
  if (slot.booked >= slot.capacity) return res.status(409).json({ error: 'Sorry, this slot just got full. Please choose another.' });

  const bookings = bookingsStore.read();
  const token = generateToken(slot.center_code, slot.date);

  const booking = {
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 8),
    token,
    farmer_name, farmer_phone, farmer_village: farmer_village || '',
    center_code: slot.center_code, center_name: slot.center_name, center_location: slot.center_location,
    date: slot.date, time: slot.time,
    crop_type, quantity,
    status: 'Booked',
    quality: null,
    transport: { status: 'Not Arranged', vehicle: '', driver: '', driver_phone: '', pickup_point: '', pickup_time: '' },
    createdBy: req.user.sub,
    createdAt: new Date().toISOString()
  };

  bookings.push(booking);
  bookingsStore.write(bookings);

  slot.booked += 1;
  slotsStore.write(slots);

  res.status(201).json(booking);
});

app.get('/api/bookings/token/:token', (req, res) => {
  const bookings = bookingsStore.read();
  const booking = bookings.find(b => b.token === req.params.token.toUpperCase());
  if (!booking) return res.status(404).json({ error: 'Token not found. Please check the token number.' });
  res.json(booking);
});

app.get('/api/bookings', (req, res) => {
  const { phone } = req.query;
  if (!phone) return res.status(400).json({ error: 'Phone number is required.' });
  const bookings = bookingsStore.read()
    .filter(b => b.farmer_phone === phone.trim())
    .sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time));
  res.json(bookings);
});

app.get('/api/admin/bookings', requireAuth, requireAdmin, (req, res) => {
  const bookings = [...bookingsStore.read()].reverse();
  res.json(bookings);
});

app.patch('/api/admin/bookings/:id', requireAuth, requireAdmin, (req, res) => {
  const bookings = bookingsStore.read();
  const booking = bookings.find(b => b.id === req.params.id);
  if (!booking) return res.status(404).json({ error: 'Booking not found.' });

  const { status, quality, transport } = req.body || {};
  if (status) booking.status = status;
  if (quality) booking.quality = { ...quality, inspectedAt: new Date().toLocaleString() };
  if (transport) booking.transport = transport;

  bookingsStore.write(bookings);
  res.json(booking);
});

/* =========================================================
   BOOT
   ========================================================= */

reseedSlots();

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Agrovision backend running on http://localhost:${PORT}`);
});
