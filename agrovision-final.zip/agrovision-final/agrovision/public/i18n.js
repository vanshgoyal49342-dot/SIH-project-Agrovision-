
(function () {
  const STORAGE_KEY = 'agrovision_lang';

  const translations = {
    en: {
      // ---- shared nav ----
      nav_book: "Book a Slot", nav_dashboard: "My Bookings", nav_lookup: "Find Token",
      nav_admin: "Admin", nav_reference: "Farmer Reference", nav_book_a_slot: "Book a slot",
      btn_logout: "Log out", whoami_prefix: "Signed in as",
      admin_access_denied: "You don't have permission to view that page.",

      // ---- index.html: login / register ----
      tab_login: "Login", tab_register: "Register",
      login_title: "Sign in", login_sub: "Enter your procurement account details to continue.",
      register_title: "Create an account", register_sub: "Register your farm or procurement centre to get started.",
      label_email: "Email or farmer ID", label_password: "Password", label_name: "Full name",
      error_email: "Enter your email or farmer ID to continue.", error_password: "Enter your password to continue.",
      remember_me: "Keep me signed in", forgot_password: "Forgot password?",
      btn_signin: "Sign in", btn_register: "Register",
      no_account: "Don't have an account?", have_account: "Already have an account?",
      link_register: "Register your farm or centre", link_login: "Sign in",
      label_state: "State", label_district: "District", label_phone: "Contact number",
      label_pincode: "State PIN code", label_aadhaar: "Aadhaar card number", label_croptype: "Type of crop",
      select_state: "Select state", crop_rabi: "Rabi", crop_kharif: "Kharif", season_other: "Other",
      error_phone: "Enter a valid 10-digit contact number.", error_pincode: "Enter a valid 6-digit PIN code.",
      error_aadhaar: "Enter a valid 12-digit Aadhaar number.",
      label_role: "Role", select_role: "Select role", role_farmer: "Farmer", role_admin: "Admin", role_procurement: "Procurement Centre",
      btn_signin_loading: "Signing in…", btn_register_loading: "Creating account…",
      error_select_role: "Please select a role.",
      error_signin_generic: "Unable to sign in. Please try again.",
      error_register_generic: "Unable to register. Please try again.",
      error_fill_required: "Please fill in your name, email/farmer ID and password.",
      placeholder_pincode_6digit: "6-digit PIN code", placeholder_aadhaar_12digit: "12-digit Aadhaar number",

      // ---- booking.html: home / slot picker ----
      home_title: "Book Your Procurement Slot",
      home_sub: "Select an available time slot at your nearest procurement centre. You'll receive a token number with your schedule, crop quality report and transport arrangement.",
      slots_heading: "Available slots",
      loading_slots: "Loading slots…", no_slots_msg: "No slots available right now. Please check back later.",
      cant_load_slots: "Could not load slots. Is the backend running?",
      choose_center_label: "1. Choose your procurement centre",
      choose_date_label: "2. Choose a date",
      choose_time_label: "3. Choose a time",
      no_times_for_date: "No time slots left for this date. Please pick another date.",
      today_label: "Today", tomorrow_label: "Tomorrow",
      seats_left_suffix: "seats left",
      book_this_slot_btn: "Book This Slot", slot_full_btn: "Full",

      // ---- vendor directory ----
      vendor_heading: "🚚 Transport & vendor directory",
      vendor_sub: "Browse registered commission agents, transporters and warehouse operators.",
      vendor_type_label: "Vendor Type", vendor_district_label: "District", vendor_select_label: "Vendor",
      vendor_all_types: "All Types", vendor_all_districts: "All Districts", vendor_select_placeholder: "Select a vendor",
      vendor_id_label: "Vendor ID:", vendor_type_field_label: "Type:", vendor_district_field_label: "District:",
      vendor_contact_label: "Contact:", vendor_vehicle_label: "Vehicle Number:", vendor_vtype_label: "Vehicle Type:",
      vendor_capacity_label: "Capacity:", vendor_capacity_unit: "Quintals", vendor_rating_label: "Rating:",

      // ---- booking confirm form ----
      confirm_booking_title: "Confirm Your Booking",
      label_full_name: "Full Name *", label_phone_number: "Phone Number *",
      placeholder_phone_10digit: "10-digit mobile number", label_village: "Village / Address",
      label_crop_type_book: "Crop Type *", placeholder_crop_type: "e.g. Wheat, Paddy, Mustard",
      label_quantity: "Quantity (in quintals) *",
      confirm_book_btn: "Confirm Booking & Get Token", confirm_book_btn_loading: "Booking…",
      summary_centre_label: "Centre:", summary_location_label: "Location:", summary_date_label: "Date:",
      summary_time_label: "Time Window:", summary_seats_label: "Seats Left:",
      slot_full_msg: "Sorry, this slot just got full. Please choose another.",
      booking_failed_generic: "Could not complete booking.",
      server_unreachable: "Could not reach the server. Is the backend running?",

      // ---- token view ----
      token_your_number: "Your Token Number", token_schedule_heading: "📅 Schedule",
      token_farmer_label: "Farmer", token_phone_label: "Phone", token_centre_label: "Centre",
      token_location_label: "Location", token_date_label: "Date", token_time_label: "Time Window",
      token_crop_label: "Crop Type", token_qty_label: "Quantity", token_qty_unit: "quintals",
      token_quality_heading: "🌾 Crop Quality Report", token_transport_heading: "🚚 Transportation Arrangement",
      quality_grade_label: "Grade", quality_moisture_label: "Moisture", quality_fm_label: "Foreign Matter",
      quality_remarks_label: "Remarks", quality_inspector_label: "Inspected By", quality_inspected_at_label: "Inspected At",
      quality_not_inspected_msg: "Not yet inspected. Quality details will appear here once your crop is graded at the centre.",
      transport_status_label: "Status", transport_vehicle_label: "Vehicle No.", transport_driver_label: "Driver",
      transport_driver_contact_label: "Driver Contact", transport_pickup_point_label: "Pickup Point",
      transport_pickup_time_label: "Pickup Time",
      transport_not_arranged_msg: "Transport not arranged yet. Please check back closer to your slot date.",
      book_another_btn: "Book Another Slot", view_all_bookings_btn: "View All My Bookings",
      token_not_found: "Token not found. Please check the token number.",

      // ---- find token / dashboard ----
      find_token_title: "Find My Token", find_token_sub: "Enter the token number you received at the time of booking.",
      label_token_number: "Token Number", placeholder_token_example: "e.g. PC01-20260908-001",
      view_details_btn: "View Details",
      my_bookings_title: "My Bookings", label_phone_search: "Phone Number",
      placeholder_search_phone: "10-digit mobile number", search_btn: "Search",
      no_bookings_found: "No bookings found for this phone number.", searching_msg: "Searching…",
      view_full_details_btn: "View Full Details", could_not_search_bookings: "Could not search bookings.",

      // ---- admin list / update ----
      all_bookings_title: "All Bookings",
      admin_note: "Update crop quality grading and transportation arrangement for each token.",
      th_token: "Token", th_farmer: "Farmer", th_centre: "Centre", th_date: "Date", th_time: "Time",
      th_crop: "Crop", th_status: "Status",
      update_btn: "Update", loading_generic: "Loading…", no_bookings_yet: "No bookings yet.",
      could_not_load_bookings: "Could not load bookings.",
      update_token_prefix: "Update Token", au_summary_farmer: "Farmer:", au_summary_centre: "Centre:", au_summary_slot: "Slot:",
      au_status_heading: "Booking Status", au_label_status: "Status",
      status_booked: "Booked", status_arrived: "Arrived", status_completed: "Completed", status_cancelled: "Cancelled",
      au_quality_heading: "Crop Quality", au_label_grade: "Grade", grade_rejected: "Rejected", au_label_moisture: "Moisture (%)",
      au_label_fm: "Foreign Matter (%)", au_label_remarks: "Remarks", au_label_inspector: "Inspected By",
      au_transport_heading: "Transportation Arrangement", au_label_tstatus: "Status",
      tstatus_not_arranged: "Not Arranged", tstatus_arranged: "Arranged", tstatus_in_transit: "In Transit", tstatus_delivered: "Delivered",
      au_label_vehicle: "Vehicle Number", au_label_driver: "Driver Name", au_label_driverphone: "Driver Contact",
      au_label_pickup: "Pickup Point", au_label_pickuptime: "Pickup Time", placeholder_pickup_time: "e.g. 09:30 AM",
      save_updates_btn: "Save Updates", update_success_msg: "Updated successfully.", update_failed_msg: "Could not save updates.",
      footer_booking: "Agrovision Procurement · Token System · Data served from the backend API.",

      // ---- reference.html ----
      ref_title: "🌾 Punjab Farmer Reference",
      ref_sub: "MSP reference + live 7-day weather outlook for all 23 Punjab districts",
      subnav_summary: "Summary", subnav_msp: "MSP Table", subnav_weather: "District Weather", subnav_notes: "Notes",
      stat_crop_count_label: "Punjab MSP crop entries", stat_districts_label: "Districts covered",
      stat_weather_horizon_label: "Weather horizon", stat_weather_horizon_value: "7 days", stat_msp_unit_label: "MSP unit",
      msp_section_heading: "📋 Punjab MSP & market-price reference",
      msp_section_sub: "MSP is the central/national rate for each crop. The market-price column is served from the backend as an illustrative sample, not live mandi data.",
      crop_search_placeholder: "Search crop…", season_all: "All seasons",
      th_crop_ref: "Crop", th_season: "Season", th_msp: "MSP 2026–27", th_market_price: "Approx. market price",
      th_vs_msp: "Vs MSP (sample)", th_sample_date: "Sample date",
      above_msp: "Above MSP", below_msp: "Below MSP",
      loading_msp_msg: "Loading MSP data…", could_not_load_msp: "Could not load MSP data. Is the backend running?",
      no_matching_crops: "No matching crops.",
      weather_section_heading: "🌦️ Weather — all Punjab districts",
      weather_section_sub: "Select a district for its 7-day forecast, fetched live from Open-Meteo. District coordinates represent the district headquarters, so local village conditions can differ.",
      district_label: "District:", weather_status_updated: "Updated live", weather_status_unable: "Unable to load",
      weather_unable_msg: "Could not fetch live weather. Please check your internet connection and try again.",
      weather_outlook_sub: "7-day outlook • representative district location",
      notes_heading: "🚜 Farmer-use notes", notice_weather_label: "Weather:",
      notice_weather_text: "Treat this as planning guidance, not a field-level warning. Check official IMD district warnings before spraying pesticides, irrigating, harvesting, or moving produce.",
      note_li_1: "Rain probability is useful for deciding whether to postpone spraying/harvesting.",
      note_li_2: "High maximum temperature can increase crop water demand and heat stress.",
      note_li_3: "Strong wind + rain can increase lodging risk in standing crops and affect spray operations.",
      note_li_4: "MSP does not mean every mandi will purchase every crop at MSP; procurement arrangements and quality specifications matter.",
      official_source_text: "Official weather reference: India Meteorological Department (IMD). Official mandi-price sources should be checked separately for live prices.",
      footer_reference: "Agrovision Procurement · MSP data served from the backend · Weather via Open-Meteo (live)."
    },

    hi: {
      nav_book: "स्लॉट बुक करें", nav_dashboard: "मेरी बुकिंग", nav_lookup: "टोकन खोजें",
      nav_admin: "एडमिन", nav_reference: "किसान संदर्भ", nav_book_a_slot: "स्लॉट बुक करें",
      btn_logout: "लॉग आउट", whoami_prefix: "साइन इन:",
      admin_access_denied: "इस पेज को देखने की आपको अनुमति नहीं है।",

      tab_login: "लॉगिन", tab_register: "पंजीकरण",
      login_title: "साइन इन करें", login_sub: "जारी रखने के लिए अपने खरीद खाते का विवरण दर्ज करें।",
      register_title: "खाता बनाएँ", register_sub: "शुरू करने के लिए अपना खेत या खरीद केंद्र पंजीकृत करें।",
      label_email: "ईमेल या किसान आईडी", label_password: "पासवर्ड", label_name: "पूरा नाम",
      error_email: "जारी रखने के लिए अपना ईमेल या किसान आईडी दर्ज करें।", error_password: "जारी रखने के लिए अपना पासवर्ड दर्ज करें।",
      remember_me: "मुझे साइन इन रखें", forgot_password: "पासवर्ड भूल गए?",
      btn_signin: "साइन इन करें", btn_register: "पंजीकरण करें",
      no_account: "खाता नहीं है?", have_account: "पहले से खाता है?",
      link_register: "अपना खेत या केंद्र पंजीकृत करें", link_login: "साइन इन करें",
      label_state: "राज्य", label_district: "जिला", label_phone: "संपर्क नंबर",
      label_pincode: "राज्य पिन कोड", label_aadhaar: "आधार कार्ड नंबर", label_croptype: "फसल का प्रकार",
      select_state: "राज्य चुनें", crop_rabi: "रबी", crop_kharif: "खरीफ", season_other: "अन्य",
      error_phone: "एक मान्य 10-अंकीय संपर्क नंबर दर्ज करें।", error_pincode: "एक मान्य 6-अंकीय पिन कोड दर्ज करें।",
      error_aadhaar: "एक मान्य 12-अंकीय आधार नंबर दर्ज करें।",
      label_role: "भूमिका", select_role: "भूमिका चुनें", role_farmer: "किसान", role_admin: "प्रशासक", role_procurement: "खरीद केंद्र",
      btn_signin_loading: "साइन इन हो रहा है…", btn_register_loading: "खाता बन रहा है…",
      error_select_role: "कृपया एक भूमिका चुनें।",
      error_signin_generic: "साइन इन नहीं हो सका। कृपया फिर से प्रयास करें।",
      error_register_generic: "पंजीकरण नहीं हो सका। कृपया फिर से प्रयास करें।",
      error_fill_required: "कृपया अपना नाम, ईमेल/किसान आईडी और पासवर्ड भरें।",
      placeholder_pincode_6digit: "6-अंकीय पिन कोड", placeholder_aadhaar_12digit: "12-अंकीय आधार नंबर",

      home_title: "अपना खरीद स्लॉट बुक करें",
      home_sub: "अपने नज़दीकी खरीद केंद्र पर उपलब्ध समय स्लॉट चुनें। आपको अपने शेड्यूल, फसल गुणवत्ता रिपोर्ट और परिवहन व्यवस्था के साथ एक टोकन नंबर मिलेगा।",
      slots_heading: "उपलब्ध स्लॉट",
      loading_slots: "स्लॉट लोड हो रहे हैं…", no_slots_msg: "अभी कोई स्लॉट उपलब्ध नहीं है। कृपया बाद में देखें।",
      cant_load_slots: "स्लॉट लोड नहीं हो सके। क्या बैकएंड चल रहा है?",
      choose_center_label: "1. अपना खरीद केंद्र चुनें",
      choose_date_label: "2. एक तारीख चुनें",
      choose_time_label: "3. एक समय चुनें",
      no_times_for_date: "इस तारीख के लिए कोई समय स्लॉट बाकी नहीं है। कृपया दूसरी तारीख चुनें।",
      today_label: "आज", tomorrow_label: "कल",
      seats_left_suffix: "सीटें बाकी",
      book_this_slot_btn: "यह स्लॉट बुक करें", slot_full_btn: "भरा हुआ",

      vendor_heading: "🚚 परिवहन और वेंडर निर्देशिका",
      vendor_sub: "पंजीकृत कमीशन एजेंट, ट्रांसपोर्टर और गोदाम संचालकों को ब्राउज़ करें।",
      vendor_type_label: "वेंडर प्रकार", vendor_district_label: "जिला", vendor_select_label: "वेंडर",
      vendor_all_types: "सभी प्रकार", vendor_all_districts: "सभी जिले", vendor_select_placeholder: "एक वेंडर चुनें",
      vendor_id_label: "वेंडर आईडी:", vendor_type_field_label: "प्रकार:", vendor_district_field_label: "जिला:",
      vendor_contact_label: "संपर्क:", vendor_vehicle_label: "वाहन नंबर:", vendor_vtype_label: "वाहन प्रकार:",
      vendor_capacity_label: "क्षमता:", vendor_capacity_unit: "क्विंटल", vendor_rating_label: "रेटिंग:",

      confirm_booking_title: "अपनी बुकिंग की पुष्टि करें",
      label_full_name: "पूरा नाम *", label_phone_number: "फ़ोन नंबर *",
      placeholder_phone_10digit: "10-अंकीय मोबाइल नंबर", label_village: "गाँव / पता",
      label_crop_type_book: "फसल का प्रकार *", placeholder_crop_type: "जैसे गेहूँ, धान, सरसों",
      label_quantity: "मात्रा (क्विंटल में) *",
      confirm_book_btn: "बुकिंग पक्की करें और टोकन पाएं", confirm_book_btn_loading: "बुक हो रहा है…",
      summary_centre_label: "केंद्र:", summary_location_label: "स्थान:", summary_date_label: "तारीख:",
      summary_time_label: "समय विंडो:", summary_seats_label: "बाकी सीटें:",
      slot_full_msg: "क्षमा करें, यह स्लॉट अभी भर गया है। कृपया कोई और चुनें।",
      booking_failed_generic: "बुकिंग पूरी नहीं हो सकी।",
      server_unreachable: "सर्वर तक नहीं पहुंच सके। क्या बैकएंड चल रहा है?",

      token_your_number: "आपका टोकन नंबर", token_schedule_heading: "📅 शेड्यूल",
      token_farmer_label: "किसान", token_phone_label: "फ़ोन", token_centre_label: "केंद्र",
      token_location_label: "स्थान", token_date_label: "तारीख", token_time_label: "समय विंडो",
      token_crop_label: "फसल का प्रकार", token_qty_label: "मात्रा", token_qty_unit: "क्विंटल",
      token_quality_heading: "🌾 फसल गुणवत्ता रिपोर्ट", token_transport_heading: "🚚 परिवहन व्यवस्था",
      quality_grade_label: "ग्रेड", quality_moisture_label: "नमी", quality_fm_label: "बाहरी पदार्थ",
      quality_remarks_label: "टिप्पणी", quality_inspector_label: "निरीक्षक", quality_inspected_at_label: "निरीक्षण समय",
      quality_not_inspected_msg: "अभी निरीक्षण नहीं हुआ है। केंद्र पर फसल की ग्रेडिंग होने पर गुणवत्ता विवरण यहाँ दिखेगा।",
      transport_status_label: "स्थिति", transport_vehicle_label: "वाहन नंबर", transport_driver_label: "चालक",
      transport_driver_contact_label: "चालक संपर्क", transport_pickup_point_label: "पिकअप स्थान",
      transport_pickup_time_label: "पिकअप समय",
      transport_not_arranged_msg: "परिवहन अभी व्यवस्थित नहीं हुआ है। कृपया अपनी स्लॉट तारीख के करीब फिर से देखें।",
      book_another_btn: "दूसरा स्लॉट बुक करें", view_all_bookings_btn: "मेरी सभी बुकिंग देखें",
      token_not_found: "टोकन नहीं मिला। कृपया टोकन नंबर जांचें।",

      find_token_title: "मेरा टोकन खोजें", find_token_sub: "बुकिंग के समय मिला टोकन नंबर दर्ज करें।",
      label_token_number: "टोकन नंबर", placeholder_token_example: "जैसे PC01-20260908-001",
      view_details_btn: "विवरण देखें",
      my_bookings_title: "मेरी बुकिंग", label_phone_search: "फ़ोन नंबर",
      placeholder_search_phone: "10-अंकीय मोबाइल नंबर", search_btn: "खोजें",
      no_bookings_found: "इस फ़ोन नंबर के लिए कोई बुकिंग नहीं मिली।", searching_msg: "खोज रहे हैं…",
      view_full_details_btn: "पूरा विवरण देखें", could_not_search_bookings: "बुकिंग खोजी नहीं जा सकी।",

      all_bookings_title: "सभी बुकिंग",
      admin_note: "प्रत्येक टोकन के लिए फसल गुणवत्ता ग्रेडिंग और परिवहन व्यवस्था अपडेट करें।",
      th_token: "टोकन", th_farmer: "किसान", th_centre: "केंद्र", th_date: "तारीख", th_time: "समय",
      th_crop: "फसल", th_status: "स्थिति",
      update_btn: "अपडेट करें", loading_generic: "लोड हो रहा है…", no_bookings_yet: "अभी कोई बुकिंग नहीं है।",
      could_not_load_bookings: "बुकिंग लोड नहीं हो सकी।",
      update_token_prefix: "टोकन अपडेट करें", au_summary_farmer: "किसान:", au_summary_centre: "केंद्र:", au_summary_slot: "स्लॉट:",
      au_status_heading: "बुकिंग स्थिति", au_label_status: "स्थिति",
      status_booked: "बुक किया गया", status_arrived: "पहुंच गया", status_completed: "पूर्ण", status_cancelled: "रद्द",
      au_quality_heading: "फसल गुणवत्ता", au_label_grade: "ग्रेड", grade_rejected: "अस्वीकृत", au_label_moisture: "नमी (%)",
      au_label_fm: "बाहरी पदार्थ (%)", au_label_remarks: "टिप्पणी", au_label_inspector: "निरीक्षक",
      au_transport_heading: "परिवहन व्यवस्था", au_label_tstatus: "स्थिति",
      tstatus_not_arranged: "व्यवस्थित नहीं", tstatus_arranged: "व्यवस्थित", tstatus_in_transit: "मार्ग में", tstatus_delivered: "पहुंचाया गया",
      au_label_vehicle: "वाहन नंबर", au_label_driver: "चालक का नाम", au_label_driverphone: "चालक संपर्क",
      au_label_pickup: "पिकअप स्थान", au_label_pickuptime: "पिकअप समय", placeholder_pickup_time: "जैसे 09:30 AM",
      save_updates_btn: "अपडेट सहेजें", update_success_msg: "सफलतापूर्वक अपडेट किया गया।", update_failed_msg: "अपडेट सहेजे नहीं जा सके।",
      footer_booking: "एग्रोविज़न प्रोक्योरमेंट · टोकन सिस्टम · डेटा बैकएंड एपीआई से।",

      ref_title: "🌾 पंजाब किसान संदर्भ",
      ref_sub: "सभी 23 पंजाब जिलों के लिए एमएसपी संदर्भ + लाइव 7-दिन मौसम पूर्वानुमान",
      subnav_summary: "सारांश", subnav_msp: "एमएसपी तालिका", subnav_weather: "जिला मौसम", subnav_notes: "नोट्स",
      stat_crop_count_label: "पंजाब एमएसपी फसल प्रविष्टियाँ", stat_districts_label: "शामिल जिले",
      stat_weather_horizon_label: "मौसम अवधि", stat_weather_horizon_value: "7 दिन", stat_msp_unit_label: "एमएसपी इकाई",
      msp_section_heading: "📋 पंजाब एमएसपी और बाज़ार-मूल्य संदर्भ",
      msp_section_sub: "एमएसपी प्रत्येक फसल के लिए केंद्रीय/राष्ट्रीय दर है। बाज़ार-मूल्य कॉलम बैकएंड से एक उदाहरण नमूने के रूप में दिया गया है, यह लाइव मंडी डेटा नहीं है।",
      crop_search_placeholder: "फसल खोजें…", season_all: "सभी मौसम",
      th_crop_ref: "फसल", th_season: "मौसम", th_msp: "एमएसपी 2026–27", th_market_price: "अनुमानित बाज़ार मूल्य",
      th_vs_msp: "एमएसपी बनाम (नमूना)", th_sample_date: "नमूना तारीख",
      above_msp: "एमएसपी से ऊपर", below_msp: "एमएसपी से नीचे",
      loading_msp_msg: "एमएसपी डेटा लोड हो रहा है…", could_not_load_msp: "एमएसपी डेटा लोड नहीं हो सका। क्या बैकएंड चल रहा है?",
      no_matching_crops: "कोई मिलती-जुलती फसल नहीं मिली।",
      weather_section_heading: "🌦️ मौसम — सभी पंजाब जिले",
      weather_section_sub: "7-दिन के पूर्वानुमान के लिए एक जिला चुनें, जो लाइव Open-Meteo से लिया गया है। जिला निर्देशांक जिला मुख्यालय को दर्शाते हैं, इसलिए स्थानीय गाँव की स्थिति अलग हो सकती है।",
      district_label: "जिला:", weather_status_updated: "लाइव अपडेट हुआ", weather_status_unable: "लोड नहीं हो सका",
      weather_unable_msg: "लाइव मौसम नहीं मिल सका। कृपया अपना इंटरनेट कनेक्शन जांचें और फिर से प्रयास करें।",
      weather_outlook_sub: "7-दिन का पूर्वानुमान • जिला मुख्यालय के अनुसार",
      notes_heading: "🚜 किसानों के लिए नोट्स", notice_weather_label: "मौसम:",
      notice_weather_text: "इसे योजना बनाने का मार्गदर्शन मानें, खेत-स्तर की चेतावनी नहीं। कीटनाशक छिड़कने, सिंचाई, कटाई या उपज ले जाने से पहले आधिकारिक IMD जिला चेतावनियाँ जांचें।",
      note_li_1: "बारिश की संभावना छिड़काव/कटाई टालने का निर्णय लेने में उपयोगी है।",
      note_li_2: "अधिक अधिकतम तापमान फसल की पानी की मांग और गर्मी के तनाव को बढ़ा सकता है।",
      note_li_3: "तेज़ हवा + बारिश खड़ी फसल में गिरने का खतरा बढ़ा सकती है और छिड़काव कार्य को प्रभावित कर सकती है।",
      note_li_4: "एमएसपी का मतलब यह नहीं कि हर मंडी हर फसल एमएसपी पर खरीदेगी; खरीद व्यवस्था और गुणवत्ता विनिर्देश मायने रखते हैं।",
      official_source_text: "आधिकारिक मौसम स्रोत: भारत मौसम विज्ञान विभाग (IMD)। लाइव कीमतों के लिए आधिकारिक मंडी-मूल्य स्रोत अलग से जांचें।",
      footer_reference: "एग्रोविज़न प्रोक्योरमेंट · एमएसपी डेटा बैकएंड से · मौसम Open-Meteo से (लाइव)।"
    },

    pa: {
      nav_book: "ਸਲਾਟ ਬੁੱਕ ਕਰੋ", nav_dashboard: "ਮੇਰੀਆਂ ਬੁਕਿੰਗਾਂ", nav_lookup: "ਟੋਕਨ ਲੱਭੋ",
      nav_admin: "ਐਡਮਿਨ", nav_reference: "ਕਿਸਾਨ ਹਵਾਲਾ", nav_book_a_slot: "ਸਲਾਟ ਬੁੱਕ ਕਰੋ",
      btn_logout: "ਲਾਗ ਆਉਟ", whoami_prefix: "ਸਾਈਨ ਇਨ:",
      admin_access_denied: "ਇਹ ਪੇਜ ਦੇਖਣ ਦੀ ਤੁਹਾਨੂੰ ਇਜਾਜ਼ਤ ਨਹੀਂ ਹੈ।",

      tab_login: "ਲਾਗਇਨ", tab_register: "ਰਜਿਸਟਰ",
      login_title: "ਸਾਈਨ ਇਨ ਕਰੋ", login_sub: "ਜਾਰੀ ਰੱਖਣ ਲਈ ਆਪਣੇ ਖਰੀਦ ਖਾਤੇ ਦੀ ਜਾਣਕਾਰੀ ਦਰਜ ਕਰੋ।",
      register_title: "ਖਾਤਾ ਬਣਾਓ", register_sub: "ਸ਼ੁਰੂ ਕਰਨ ਲਈ ਆਪਣਾ ਫਾਰਮ ਜਾਂ ਖਰੀਦ ਕੇਂਦਰ ਰਜਿਸਟਰ ਕਰੋ।",
      label_email: "ਈਮੇਲ ਜਾਂ ਕਿਸਾਨ ਆਈਡੀ", label_password: "ਪਾਸਵਰਡ", label_name: "ਪੂਰਾ ਨਾਮ",
      error_email: "ਜਾਰੀ ਰੱਖਣ ਲਈ ਆਪਣੀ ਈਮੇਲ ਜਾਂ ਕਿਸਾਨ ਆਈਡੀ ਦਰਜ ਕਰੋ।", error_password: "ਜਾਰੀ ਰੱਖਣ ਲਈ ਆਪਣਾ ਪਾਸਵਰਡ ਦਰਜ ਕਰੋ।",
      remember_me: "ਮੈਨੂੰ ਸਾਈਨ ਇਨ ਰੱਖੋ", forgot_password: "ਪਾਸਵਰਡ ਭੁੱਲ ਗਏ?",
      btn_signin: "ਸਾਈਨ ਇਨ ਕਰੋ", btn_register: "ਰਜਿਸਟਰ ਕਰੋ",
      no_account: "ਖਾਤਾ ਨਹੀਂ ਹੈ?", have_account: "ਪਹਿਲਾਂ ਤੋਂ ਖਾਤਾ ਹੈ?",
      link_register: "ਆਪਣਾ ਫਾਰਮ ਜਾਂ ਕੇਂਦਰ ਰਜਿਸਟਰ ਕਰੋ", link_login: "ਸਾਈਨ ਇਨ ਕਰੋ",
      label_state: "ਰਾਜ", label_district: "ਜ਼ਿਲ੍ਹਾ", label_phone: "ਸੰਪਰਕ ਨੰਬਰ",
      label_pincode: "ਰਾਜ ਪਿੰਨ ਕੋਡ", label_aadhaar: "ਆਧਾਰ ਕਾਰਡ ਨੰਬਰ", label_croptype: "ਫਸਲ ਦੀ ਕਿਸਮ",
      select_state: "ਰਾਜ ਚੁਣੋ", crop_rabi: "ਹਾੜੀ (ਰਬੀ)", crop_kharif: "ਸਾਉਣੀ (ਖਰੀਫ)", season_other: "ਹੋਰ",
      error_phone: "ਇੱਕ ਵੈਧ 10-ਅੰਕੀ ਸੰਪਰਕ ਨੰਬਰ ਦਰਜ ਕਰੋ।", error_pincode: "ਇੱਕ ਵੈਧ 6-ਅੰਕੀ ਪਿੰਨ ਕੋਡ ਦਰਜ ਕਰੋ।",
      error_aadhaar: "ਇੱਕ ਵੈਧ 12-ਅੰਕੀ ਆਧਾਰ ਨੰਬਰ ਦਰਜ ਕਰੋ।",
      label_role: "ਭੂਮਿਕਾ", select_role: "ਭੂਮਿਕਾ ਚੁਣੋ", role_farmer: "ਕਿਸਾਨ", role_admin: "ਪ੍ਰਸ਼ਾਸਕ", role_procurement: "ਖਰੀਦ ਕੇਂਦਰ",
      btn_signin_loading: "ਸਾਈਨ ਇਨ ਹੋ ਰਿਹਾ ਹੈ…", btn_register_loading: "ਖਾਤਾ ਬਣ ਰਿਹਾ ਹੈ…",
      error_select_role: "ਕਿਰਪਾ ਕਰਕੇ ਇੱਕ ਭੂਮਿਕਾ ਚੁਣੋ।",
      error_signin_generic: "ਸਾਈਨ ਇਨ ਨਹੀਂ ਹੋ ਸਕਿਆ। ਕਿਰਪਾ ਕਰਕੇ ਦੁਬਾਰਾ ਕੋਸ਼ਿਸ਼ ਕਰੋ।",
      error_register_generic: "ਰਜਿਸਟਰ ਨਹੀਂ ਹੋ ਸਕਿਆ। ਕਿਰਪਾ ਕਰਕੇ ਦੁਬਾਰਾ ਕੋਸ਼ਿਸ਼ ਕਰੋ।",
      error_fill_required: "ਕਿਰਪਾ ਕਰਕੇ ਆਪਣਾ ਨਾਮ, ਈਮੇਲ/ਕਿਸਾਨ ਆਈਡੀ ਅਤੇ ਪਾਸਵਰਡ ਭਰੋ।",
      placeholder_pincode_6digit: "6-ਅੰਕੀ ਪਿੰਨ ਕੋਡ", placeholder_aadhaar_12digit: "12-ਅੰਕੀ ਆਧਾਰ ਨੰਬਰ",

      home_title: "ਆਪਣਾ ਖਰੀਦ ਸਲਾਟ ਬੁੱਕ ਕਰੋ",
      home_sub: "ਆਪਣੇ ਨੇੜਲੇ ਖਰੀਦ ਕੇਂਦਰ 'ਤੇ ਉਪਲਬਧ ਸਮਾਂ ਸਲਾਟ ਚੁਣੋ। ਤੁਹਾਨੂੰ ਆਪਣੇ ਸ਼ਡਿਊਲ, ਫਸਲ ਗੁਣਵੱਤਾ ਰਿਪੋਰਟ ਅਤੇ ਟਰਾਂਸਪੋਰਟ ਪ੍ਰਬੰਧ ਨਾਲ ਇੱਕ ਟੋਕਨ ਨੰਬਰ ਮਿਲੇਗਾ।",
      slots_heading: "ਉਪਲਬਧ ਸਲਾਟ",
      loading_slots: "ਸਲਾਟ ਲੋਡ ਹੋ ਰਹੇ ਹਨ…", no_slots_msg: "ਹੁਣੇ ਕੋਈ ਸਲਾਟ ਉਪਲਬਧ ਨਹੀਂ ਹੈ। ਕਿਰਪਾ ਕਰਕੇ ਬਾਅਦ ਵਿੱਚ ਦੇਖੋ।",
      cant_load_slots: "ਸਲਾਟ ਲੋਡ ਨਹੀਂ ਹੋ ਸਕੇ। ਕੀ ਬੈਕਐਂਡ ਚੱਲ ਰਿਹਾ ਹੈ?",
      choose_center_label: "1. ਆਪਣਾ ਖਰੀਦ ਕੇਂਦਰ ਚੁਣੋ",
      choose_date_label: "2. ਇੱਕ ਤਾਰੀਖ ਚੁਣੋ",
      choose_time_label: "3. ਇੱਕ ਸਮਾਂ ਚੁਣੋ",
      no_times_for_date: "ਇਸ ਤਾਰੀਖ ਲਈ ਕੋਈ ਸਮਾਂ ਸਲਾਟ ਬਾਕੀ ਨਹੀਂ ਹੈ। ਕਿਰਪਾ ਕਰਕੇ ਕੋਈ ਹੋਰ ਤਾਰੀਖ ਚੁਣੋ।",
      today_label: "ਅੱਜ", tomorrow_label: "ਕੱਲ੍ਹ",
      seats_left_suffix: "ਸੀਟਾਂ ਬਾਕੀ",
      book_this_slot_btn: "ਇਹ ਸਲਾਟ ਬੁੱਕ ਕਰੋ", slot_full_btn: "ਭਰ ਗਿਆ",

      vendor_heading: "🚚 ਟਰਾਂਸਪੋਰਟ ਅਤੇ ਵੇਂਡਰ ਡਾਇਰੈਕਟਰੀ",
      vendor_sub: "ਰਜਿਸਟਰਡ ਕਮਿਸ਼ਨ ਏਜੰਟ, ਟਰਾਂਸਪੋਰਟਰ ਅਤੇ ਗੋਦਾਮ ਸੰਚਾਲਕ ਬ੍ਰਾਊਜ਼ ਕਰੋ।",
      vendor_type_label: "ਵੇਂਡਰ ਕਿਸਮ", vendor_district_label: "ਜ਼ਿਲ੍ਹਾ", vendor_select_label: "ਵੇਂਡਰ",
      vendor_all_types: "ਸਾਰੀਆਂ ਕਿਸਮਾਂ", vendor_all_districts: "ਸਾਰੇ ਜ਼ਿਲ੍ਹੇ", vendor_select_placeholder: "ਇੱਕ ਵੇਂਡਰ ਚੁਣੋ",
      vendor_id_label: "ਵੇਂਡਰ ਆਈਡੀ:", vendor_type_field_label: "ਕਿਸਮ:", vendor_district_field_label: "ਜ਼ਿਲ੍ਹਾ:",
      vendor_contact_label: "ਸੰਪਰਕ:", vendor_vehicle_label: "ਵਾਹਨ ਨੰਬਰ:", vendor_vtype_label: "ਵਾਹਨ ਕਿਸਮ:",
      vendor_capacity_label: "ਸਮਰੱਥਾ:", vendor_capacity_unit: "ਕੁਇੰਟਲ", vendor_rating_label: "ਰੇਟਿੰਗ:",

      confirm_booking_title: "ਆਪਣੀ ਬੁਕਿੰਗ ਦੀ ਪੁਸ਼ਟੀ ਕਰੋ",
      label_full_name: "ਪੂਰਾ ਨਾਮ *", label_phone_number: "ਫ਼ੋਨ ਨੰਬਰ *",
      placeholder_phone_10digit: "10-ਅੰਕੀ ਮੋਬਾਈਲ ਨੰਬਰ", label_village: "ਪਿੰਡ / ਪਤਾ",
      label_crop_type_book: "ਫਸਲ ਦੀ ਕਿਸਮ *", placeholder_crop_type: "ਜਿਵੇਂ ਕਣਕ, ਝੋਨਾ, ਸਰ੍ਹੋਂ",
      label_quantity: "ਮਾਤਰਾ (ਕੁਇੰਟਲ ਵਿੱਚ) *",
      confirm_book_btn: "ਬੁਕਿੰਗ ਪੱਕੀ ਕਰੋ ਅਤੇ ਟੋਕਨ ਲਵੋ", confirm_book_btn_loading: "ਬੁੱਕ ਹੋ ਰਿਹਾ ਹੈ…",
      summary_centre_label: "ਕੇਂਦਰ:", summary_location_label: "ਸਥਾਨ:", summary_date_label: "ਤਾਰੀਖ:",
      summary_time_label: "ਸਮਾਂ ਵਿੰਡੋ:", summary_seats_label: "ਬਾਕੀ ਸੀਟਾਂ:",
      slot_full_msg: "ਮਾਫ਼ ਕਰਨਾ, ਇਹ ਸਲਾਟ ਹੁਣੇ ਭਰ ਗਿਆ ਹੈ। ਕਿਰਪਾ ਕਰਕੇ ਕੋਈ ਹੋਰ ਚੁਣੋ।",
      booking_failed_generic: "ਬੁਕਿੰਗ ਪੂਰੀ ਨਹੀਂ ਹੋ ਸਕੀ।",
      server_unreachable: "ਸਰਵਰ ਤੱਕ ਨਹੀਂ ਪਹੁੰਚ ਸਕੇ। ਕੀ ਬੈਕਐਂਡ ਚੱਲ ਰਿਹਾ ਹੈ?",

      token_your_number: "ਤੁਹਾਡਾ ਟੋਕਨ ਨੰਬਰ", token_schedule_heading: "📅 ਸ਼ਡਿਊਲ",
      token_farmer_label: "ਕਿਸਾਨ", token_phone_label: "ਫ਼ੋਨ", token_centre_label: "ਕੇਂਦਰ",
      token_location_label: "ਸਥਾਨ", token_date_label: "ਤਾਰੀਖ", token_time_label: "ਸਮਾਂ ਵਿੰਡੋ",
      token_crop_label: "ਫਸਲ ਦੀ ਕਿਸਮ", token_qty_label: "ਮਾਤਰਾ", token_qty_unit: "ਕੁਇੰਟਲ",
      token_quality_heading: "🌾 ਫਸਲ ਗੁਣਵੱਤਾ ਰਿਪੋਰਟ", token_transport_heading: "🚚 ਟਰਾਂਸਪੋਰਟ ਪ੍ਰਬੰਧ",
      quality_grade_label: "ਗ੍ਰੇਡ", quality_moisture_label: "ਨਮੀ", quality_fm_label: "ਬਾਹਰੀ ਪਦਾਰਥ",
      quality_remarks_label: "ਟਿੱਪਣੀ", quality_inspector_label: "ਨਿਰੀਖਕ", quality_inspected_at_label: "ਨਿਰੀਖਣ ਸਮਾਂ",
      quality_not_inspected_msg: "ਅਜੇ ਨਿਰੀਖਣ ਨਹੀਂ ਹੋਇਆ। ਕੇਂਦਰ 'ਤੇ ਫਸਲ ਦੀ ਗ੍ਰੇਡਿੰਗ ਹੋਣ 'ਤੇ ਗੁਣਵੱਤਾ ਵੇਰਵੇ ਇੱਥੇ ਦਿਖਣਗੇ।",
      transport_status_label: "ਸਥਿਤੀ", transport_vehicle_label: "ਵਾਹਨ ਨੰਬਰ", transport_driver_label: "ਡਰਾਈਵਰ",
      transport_driver_contact_label: "ਡਰਾਈਵਰ ਸੰਪਰਕ", transport_pickup_point_label: "ਪਿਕਅੱਪ ਸਥਾਨ",
      transport_pickup_time_label: "ਪਿਕਅੱਪ ਸਮਾਂ",
      transport_not_arranged_msg: "ਟਰਾਂਸਪੋਰਟ ਅਜੇ ਪ੍ਰਬੰਧ ਨਹੀਂ ਹੋਇਆ। ਕਿਰਪਾ ਕਰਕੇ ਆਪਣੀ ਸਲਾਟ ਤਾਰੀਖ ਦੇ ਨੇੜੇ ਫਿਰ ਦੇਖੋ।",
      book_another_btn: "ਹੋਰ ਸਲਾਟ ਬੁੱਕ ਕਰੋ", view_all_bookings_btn: "ਮੇਰੀਆਂ ਸਾਰੀਆਂ ਬੁਕਿੰਗਾਂ ਦੇਖੋ",
      token_not_found: "ਟੋਕਨ ਨਹੀਂ ਮਿਲਿਆ। ਕਿਰਪਾ ਕਰਕੇ ਟੋਕਨ ਨੰਬਰ ਜਾਂਚੋ।",

      find_token_title: "ਮੇਰਾ ਟੋਕਨ ਲੱਭੋ", find_token_sub: "ਬੁਕਿੰਗ ਸਮੇਂ ਮਿਲਿਆ ਟੋਕਨ ਨੰਬਰ ਦਰਜ ਕਰੋ।",
      label_token_number: "ਟੋਕਨ ਨੰਬਰ", placeholder_token_example: "ਜਿਵੇਂ PC01-20260908-001",
      view_details_btn: "ਵੇਰਵੇ ਦੇਖੋ",
      my_bookings_title: "ਮੇਰੀਆਂ ਬੁਕਿੰਗਾਂ", label_phone_search: "ਫ਼ੋਨ ਨੰਬਰ",
      placeholder_search_phone: "10-ਅੰਕੀ ਮੋਬਾਈਲ ਨੰਬਰ", search_btn: "ਖੋਜੋ",
      no_bookings_found: "ਇਸ ਫ਼ੋਨ ਨੰਬਰ ਲਈ ਕੋਈ ਬੁਕਿੰਗ ਨਹੀਂ ਮਿਲੀ।", searching_msg: "ਖੋਜ ਰਹੇ ਹਾਂ…",
      view_full_details_btn: "ਪੂਰੇ ਵੇਰਵੇ ਦੇਖੋ", could_not_search_bookings: "ਬੁਕਿੰਗ ਖੋਜੀ ਨਹੀਂ ਜਾ ਸਕੀ।",

      all_bookings_title: "ਸਾਰੀਆਂ ਬੁਕਿੰਗਾਂ",
      admin_note: "ਹਰੇਕ ਟੋਕਨ ਲਈ ਫਸਲ ਗੁਣਵੱਤਾ ਗ੍ਰੇਡਿੰਗ ਅਤੇ ਟਰਾਂਸਪੋਰਟ ਪ੍ਰਬੰਧ ਅੱਪਡੇਟ ਕਰੋ।",
      th_token: "ਟੋਕਨ", th_farmer: "ਕਿਸਾਨ", th_centre: "ਕੇਂਦਰ", th_date: "ਤਾਰੀਖ", th_time: "ਸਮਾਂ",
      th_crop: "ਫਸਲ", th_status: "ਸਥਿਤੀ",
      update_btn: "ਅੱਪਡੇਟ ਕਰੋ", loading_generic: "ਲੋਡ ਹੋ ਰਿਹਾ ਹੈ…", no_bookings_yet: "ਅਜੇ ਕੋਈ ਬੁਕਿੰਗ ਨਹੀਂ ਹੈ।",
      could_not_load_bookings: "ਬੁਕਿੰਗ ਲੋਡ ਨਹੀਂ ਹੋ ਸਕੀ।",
      update_token_prefix: "ਟੋਕਨ ਅੱਪਡੇਟ ਕਰੋ", au_summary_farmer: "ਕਿਸਾਨ:", au_summary_centre: "ਕੇਂਦਰ:", au_summary_slot: "ਸਲਾਟ:",
      au_status_heading: "ਬੁਕਿੰਗ ਸਥਿਤੀ", au_label_status: "ਸਥਿਤੀ",
      status_booked: "ਬੁੱਕ ਕੀਤਾ", status_arrived: "ਪਹੁੰਚ ਗਿਆ", status_completed: "ਪੂਰਾ", status_cancelled: "ਰੱਦ",
      au_quality_heading: "ਫਸਲ ਗੁਣਵੱਤਾ", au_label_grade: "ਗ੍ਰੇਡ", grade_rejected: "ਰੱਦ", au_label_moisture: "ਨਮੀ (%)",
      au_label_fm: "ਬਾਹਰੀ ਪਦਾਰਥ (%)", au_label_remarks: "ਟਿੱਪਣੀ", au_label_inspector: "ਨਿਰੀਖਕ",
      au_transport_heading: "ਟਰਾਂਸਪੋਰਟ ਪ੍ਰਬੰਧ", au_label_tstatus: "ਸਥਿਤੀ",
      tstatus_not_arranged: "ਪ੍ਰਬੰਧ ਨਹੀਂ", tstatus_arranged: "ਪ੍ਰਬੰਧ ਹੋਇਆ", tstatus_in_transit: "ਰਸਤੇ ਵਿੱਚ", tstatus_delivered: "ਪਹੁੰਚਾਇਆ ਗਿਆ",
      au_label_vehicle: "ਵਾਹਨ ਨੰਬਰ", au_label_driver: "ਡਰਾਈਵਰ ਦਾ ਨਾਮ", au_label_driverphone: "ਡਰਾਈਵਰ ਸੰਪਰਕ",
      au_label_pickup: "ਪਿਕਅੱਪ ਸਥਾਨ", au_label_pickuptime: "ਪਿਕਅੱਪ ਸਮਾਂ", placeholder_pickup_time: "ਜਿਵੇਂ 09:30 AM",
      save_updates_btn: "ਅੱਪਡੇਟ ਸੰਭਾਲੋ", update_success_msg: "ਸਫਲਤਾਪੂਰਵਕ ਅੱਪਡੇਟ ਹੋਇਆ।", update_failed_msg: "ਅੱਪਡੇਟ ਸੰਭਾਲਿਆ ਨਹੀਂ ਜਾ ਸਕਿਆ।",
      footer_booking: "ਐਗਰੋਵਿਜ਼ਨ ਪ੍ਰੋਕਿਓਰਮੈਂਟ · ਟੋਕਨ ਸਿਸਟਮ · ਡਾਟਾ ਬੈਕਐਂਡ API ਤੋਂ।",

      ref_title: "🌾 ਪੰਜਾਬ ਕਿਸਾਨ ਹਵਾਲਾ",
      ref_sub: "ਸਾਰੇ 23 ਪੰਜਾਬ ਜ਼ਿਲ੍ਹਿਆਂ ਲਈ ਐਮਐਸਪੀ ਹਵਾਲਾ + ਲਾਈਵ 7-ਦਿਨ ਮੌਸਮ ਪੂਰਵ ਅਨੁਮਾਨ",
      subnav_summary: "ਸਾਰ", subnav_msp: "ਐਮਐਸਪੀ ਸਾਰਣੀ", subnav_weather: "ਜ਼ਿਲ੍ਹਾ ਮੌਸਮ", subnav_notes: "ਨੋਟਸ",
      stat_crop_count_label: "ਪੰਜਾਬ ਐਮਐਸਪੀ ਫਸਲ ਐਂਟਰੀਆਂ", stat_districts_label: "ਸ਼ਾਮਲ ਜ਼ਿਲ੍ਹੇ",
      stat_weather_horizon_label: "ਮੌਸਮ ਮਿਆਦ", stat_weather_horizon_value: "7 ਦਿਨ", stat_msp_unit_label: "ਐਮਐਸਪੀ ਇਕਾਈ",
      msp_section_heading: "📋 ਪੰਜਾਬ ਐਮਐਸਪੀ ਅਤੇ ਬਾਜ਼ਾਰ-ਮੁੱਲ ਹਵਾਲਾ",
      msp_section_sub: "ਐਮਐਸਪੀ ਹਰੇਕ ਫਸਲ ਲਈ ਕੇਂਦਰੀ/ਰਾਸ਼ਟਰੀ ਦਰ ਹੈ। ਬਾਜ਼ਾਰ-ਮੁੱਲ ਕਾਲਮ ਬੈਕਐਂਡ ਤੋਂ ਇੱਕ ਉਦਾਹਰਣ ਨਮੂਨੇ ਵਜੋਂ ਦਿੱਤਾ ਗਿਆ ਹੈ, ਇਹ ਲਾਈਵ ਮੰਡੀ ਡਾਟਾ ਨਹੀਂ ਹੈ।",
      crop_search_placeholder: "ਫਸਲ ਖੋਜੋ…", season_all: "ਸਾਰੇ ਮੌਸਮ",
      th_crop_ref: "ਫਸਲ", th_season: "ਮੌਸਮ", th_msp: "ਐਮਐਸਪੀ 2026–27", th_market_price: "ਅੰਦਾਜ਼ਨ ਬਾਜ਼ਾਰ ਮੁੱਲ",
      th_vs_msp: "ਐਮਐਸਪੀ ਬਨਾਮ (ਨਮੂਨਾ)", th_sample_date: "ਨਮੂਨਾ ਤਾਰੀਖ",
      above_msp: "ਐਮਐਸਪੀ ਤੋਂ ਵੱਧ", below_msp: "ਐਮਐਸਪੀ ਤੋਂ ਘੱਟ",
      loading_msp_msg: "ਐਮਐਸਪੀ ਡਾਟਾ ਲੋਡ ਹੋ ਰਿਹਾ ਹੈ…", could_not_load_msp: "ਐਮਐਸਪੀ ਡਾਟਾ ਲੋਡ ਨਹੀਂ ਹੋ ਸਕਿਆ। ਕੀ ਬੈਕਐਂਡ ਚੱਲ ਰਿਹਾ ਹੈ?",
      no_matching_crops: "ਕੋਈ ਮਿਲਦੀ ਫਸਲ ਨਹੀਂ ਮਿਲੀ।",
      weather_section_heading: "🌦️ ਮੌਸਮ — ਸਾਰੇ ਪੰਜਾਬ ਜ਼ਿਲ੍ਹੇ",
      weather_section_sub: "7-ਦਿਨ ਦੇ ਪੂਰਵ ਅਨੁਮਾਨ ਲਈ ਇੱਕ ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ, ਜੋ ਲਾਈਵ Open-Meteo ਤੋਂ ਲਿਆ ਗਿਆ ਹੈ। ਜ਼ਿਲ੍ਹਾ ਧੁਰੇ ਜ਼ਿਲ੍ਹਾ ਹੈੱਡਕੁਆਰਟਰ ਨੂੰ ਦਰਸਾਉਂਦੇ ਹਨ, ਇਸ ਲਈ ਸਥਾਨਕ ਪਿੰਡ ਦੀ ਸਥਿਤੀ ਵੱਖਰੀ ਹੋ ਸਕਦੀ ਹੈ।",
      district_label: "ਜ਼ਿਲ੍ਹਾ:", weather_status_updated: "ਲਾਈਵ ਅੱਪਡੇਟ ਹੋਇਆ", weather_status_unable: "ਲੋਡ ਨਹੀਂ ਹੋ ਸਕਿਆ",
      weather_unable_msg: "ਲਾਈਵ ਮੌਸਮ ਨਹੀਂ ਮਿਲ ਸਕਿਆ। ਕਿਰਪਾ ਕਰਕੇ ਆਪਣਾ ਇੰਟਰਨੈੱਟ ਕਨੈਕਸ਼ਨ ਜਾਂਚੋ ਅਤੇ ਦੁਬਾਰਾ ਕੋਸ਼ਿਸ਼ ਕਰੋ।",
      weather_outlook_sub: "7-ਦਿਨ ਦਾ ਪੂਰਵ ਅਨੁਮਾਨ • ਜ਼ਿਲ੍ਹਾ ਹੈੱਡਕੁਆਰਟਰ ਅਨੁਸਾਰ",
      notes_heading: "🚜 ਕਿਸਾਨਾਂ ਲਈ ਨੋਟਸ", notice_weather_label: "ਮੌਸਮ:",
      notice_weather_text: "ਇਸਨੂੰ ਯੋਜਨਾ ਬਣਾਉਣ ਦਾ ਮਾਰਗਦਰਸ਼ਨ ਸਮਝੋ, ਖੇਤ-ਪੱਧਰ ਦੀ ਚੇਤਾਵਨੀ ਨਹੀਂ। ਕੀਟਨਾਸ਼ਕ ਛਿੜਕਣ, ਸਿੰਚਾਈ, ਵਾਢੀ ਜਾਂ ਫਸਲ ਲਿਜਾਣ ਤੋਂ ਪਹਿਲਾਂ ਅਧਿਕਾਰਤ IMD ਜ਼ਿਲ੍ਹਾ ਚੇਤਾਵਨੀਆਂ ਜਾਂਚੋ।",
      note_li_1: "ਬਾਰਿਸ਼ ਦੀ ਸੰਭਾਵਨਾ ਛਿੜਕਾਅ/ਵਾਢੀ ਟਾਲਣ ਦਾ ਫੈਸਲਾ ਲੈਣ ਵਿੱਚ ਲਾਭਦਾਇਕ ਹੈ।",
      note_li_2: "ਵੱਧ ਤੋਂ ਵੱਧ ਤਾਪਮਾਨ ਫਸਲ ਦੀ ਪਾਣੀ ਦੀ ਲੋੜ ਅਤੇ ਗਰਮੀ ਦਾ ਦਬਾਅ ਵਧਾ ਸਕਦਾ ਹੈ।",
      note_li_3: "ਤੇਜ਼ ਹਵਾ + ਬਾਰਿਸ਼ ਖੜ੍ਹੀ ਫਸਲ ਦੇ ਡਿੱਗਣ ਦਾ ਖਤਰਾ ਵਧਾ ਸਕਦੀ ਹੈ ਅਤੇ ਛਿੜਕਾਅ ਕੰਮ ਨੂੰ ਪ੍ਰਭਾਵਿਤ ਕਰ ਸਕਦੀ ਹੈ।",
      note_li_4: "ਐਮਐਸਪੀ ਦਾ ਮਤਲਬ ਇਹ ਨਹੀਂ ਕਿ ਹਰ ਮੰਡੀ ਹਰ ਫਸਲ ਐਮਐਸਪੀ 'ਤੇ ਖਰੀਦੇਗੀ; ਖਰੀਦ ਪ੍ਰਬੰਧ ਅਤੇ ਗੁਣਵੱਤਾ ਮਾਪਦੰਡ ਮਾਇਨੇ ਰੱਖਦੇ ਹਨ।",
      official_source_text: "ਅਧਿਕਾਰਤ ਮੌਸਮ ਸਰੋਤ: ਭਾਰਤ ਮੌਸਮ ਵਿਗਿਆਨ ਵਿਭਾਗ (IMD)। ਲਾਈਵ ਕੀਮਤਾਂ ਲਈ ਅਧਿਕਾਰਤ ਮੰਡੀ-ਮੁੱਲ ਸਰੋਤ ਵੱਖਰੇ ਤੌਰ 'ਤੇ ਜਾਂਚੋ।",
      footer_reference: "ਐਗਰੋਵਿਜ਼ਨ ਪ੍ਰੋਕਿਓਰਮੈਂਟ · ਐਮਐਸਪੀ ਡਾਟਾ ਬੈਕਐਂਡ ਤੋਂ · ਮੌਸਮ Open-Meteo ਤੋਂ (ਲਾਈਵ)।"
    }
  };

 
  const enumTables = {
    status: { key: s => 'status_' + s.toLowerCase().replace(/ /g, '_') },
    tstatus: { key: s => 'tstatus_' + s.toLowerCase().replace(/ /g, '_') }
  };

  // Weather
  const weatherCodes = {
    en: { 0: "Clear", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
      45: "Fog", 48: "Rime fog", 51: "Light drizzle", 53: "Drizzle", 55: "Heavy drizzle",
      61: "Light rain", 63: "Rain", 65: "Heavy rain",
      71: "Light snow", 73: "Snow", 75: "Heavy snow",
      80: "Rain showers", 81: "Rain showers", 82: "Heavy showers",
      95: "Thunderstorm", 96: "Thunderstorm + hail", 99: "Thunderstorm + hail", default: "Mixed conditions" },
    hi: { 0: "साफ़", 1: "मुख्यतः साफ़", 2: "आंशिक बादल", 3: "घना बादल",
      45: "कोहरा", 48: "पाला कोहरा", 51: "हल्की बूंदाबांदी", 53: "बूंदाबांदी", 55: "तेज़ बूंदाबांदी",
      61: "हल्की बारिश", 63: "बारिश", 65: "भारी बारिश",
      71: "हल्की बर्फ", 73: "बर्फ", 75: "भारी बर्फ",
      80: "बारिश की बौछारें", 81: "बारिश की बौछारें", 82: "तेज़ बौछारें",
      95: "आंधी-तूफान", 96: "ओलों के साथ तूफान", 99: "ओलों के साथ तूफान", default: "मिश्रित मौसम" },
    pa: { 0: "ਸਾਫ਼", 1: "ਜਿਆਦਾਤਰ ਸਾਫ਼", 2: "ਅੰਸ਼ਕ ਬੱਦਲ", 3: "ਪੂਰੀ ਤਰ੍ਹਾਂ ਬੱਦਲ",
      45: "ਧੁੰਦ", 48: "ਕੋਰਾ ਧੁੰਦ", 51: "ਹਲਕੀ ਬੂੰਦਾ-ਬਾਂਦੀ", 53: "ਬੂੰਦਾ-ਬਾਂਦੀ", 55: "ਤੇਜ਼ ਬੂੰਦਾ-ਬਾਂਦੀ",
      61: "ਹਲਕੀ ਬਾਰਿਸ਼", 63: "ਬਾਰਿਸ਼", 65: "ਭਾਰੀ ਬਾਰਿਸ਼",
      71: "ਹਲਕੀ ਬਰਫ਼", 73: "ਬਰਫ਼", 75: "ਭਾਰੀ ਬਰਫ਼",
      80: "ਬਾਰਿਸ਼ ਦੀਆਂ ਫੁਹਾਰਾਂ", 81: "ਬਾਰਿਸ਼ ਦੀਆਂ ਫੁਹਾਰਾਂ", 82: "ਤੇਜ਼ ਫੁਹਾਰਾਂ",
      95: "ਗਰਜ-ਤੂਫ਼ਾਨ", 96: "ਗੜਿਆਂ ਨਾਲ ਤੂਫ਼ਾਨ", 99: "ਗੜਿਆਂ ਨਾਲ ਤੂਫ਼ਾਨ", default: "ਮਿਲਿਆ-ਜੁਲਿਆ ਮੌਸਮ" }
  };
  function weatherDesc(code) {
    const lang = getLang();
    const table = weatherCodes[lang] || weatherCodes.en;
    return table[code] || table.default;
  }

  function getLang() {
    return localStorage.getItem(STORAGE_KEY) || 'en';
  }
  function setLang(lang) {
    localStorage.setItem(STORAGE_KEY, lang);
  }
  function t(key) {
    const lang = getLang();
    const dict = translations[lang] || translations.en;
    return dict[key] || translations.en[key] || key;
  }
 
  
  function tEnum(table, value) {
    if (!value) return value;
    const spec = enumTables[table];
    if (!spec) return value;
    return t(spec.key(value));
  }
  function localeFor(lang) {
    return { en: 'en-IN', hi: 'hi-IN', pa: 'pa-IN' }[lang] || 'en-IN';
  }
  function applyI18n(root) {
    root = root || document;
    const lang = getLang();
    document.documentElement.lang = lang;
    root.querySelectorAll('[data-i18n]').forEach(el => {
      el.textContent = t(el.getAttribute('data-i18n'));
    });
    root.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
      el.setAttribute('placeholder', t(el.getAttribute('data-i18n-placeholder')));
    });
  }
  function initLangSwitcher(selectEl, onChange) {
    if (!selectEl) return;
    selectEl.value = getLang();
    selectEl.addEventListener('change', (e) => {
      setLang(e.target.value);
      applyI18n(document);
      if (typeof onChange === 'function') onChange(e.target.value);
    });
  }

  window.AgroI18N = { translations, getLang, setLang, t, tEnum, localeFor, weatherDesc, applyI18n, initLangSwitcher };
})();
